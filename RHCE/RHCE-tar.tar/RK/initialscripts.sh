wget http://content/Rhce/admin.yml
ansible-playbook admin.yml
